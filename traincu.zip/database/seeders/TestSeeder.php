<?php

namespace Database\Seeders;

use App\Models\CustomerDetail;
use App\Models\User;
use Illuminate\Database\Seeder;
use Spatie\Permission\Models\Role;

class TestSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        // User::insert([
        //     "name" => "Bappi Saha",
        //     "email" => "bappi2097@gmail.com",
        //     "mobile_no" => "01726257333",
        //     "password" => bcrypt("password"),
        // ]);
        // $customers = new CustomerDetail();
        // $customers->
    }
}
