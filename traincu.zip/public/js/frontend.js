/******/ (() => { // webpackBootstrap
/*!*******************************************!*\
  !*** ./resources/js/frontend/frontend.js ***!
  \*******************************************/
sidebarLinkToggle = function sidebarLinkToggle(e) {
  e.nextElementSibling.classList.toggle("d-block");
  e.childNodes[5].classList.toggle("icon-down");
};
/******/ })()
;