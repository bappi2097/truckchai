sidebarLinkToggle = (e) => {
    e.nextElementSibling.classList.toggle("d-block");
    e.childNodes[5].classList.toggle("icon-down");
};