<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Authentication Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines are used during authentication for various
    | messages that we need to display to the user. You are free to modify
    | these language lines according to your application's requirements.
    |
    */
    'hire-truck-now' => "ابھی ایک ٹرک کی خدمات حاصل کریں",
    'hire-truck' => "  کرایہ پر ٹرک",
    'download-app' => "اپلی کیشن ڈاؤن لوڈ کریں  ",
];
