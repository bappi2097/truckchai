<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Authentication Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines are used during authentication for various
    | messages that we need to display to the user. You are free to modify
    | these language lines according to your application's requirements.
    |
    */
    'home' => "گھر",
    'truck-operator' => "ٹرک آپریٹر  ",
    'blog' => "بلاگ  ",
    'contact-us' => "ہم سے رابطہ کریں  ",
    'login' => " لاگ ان کریں ",
    'register' => "رجسٹر  ",
    'dashboard' => "ڈیش بورڈ  ",
];
