<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Authentication Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines are used during authentication for various
    | messages that we need to display to the user. You are free to modify
    | these language lines according to your application's requirements.
    |
    */
    'why-register-traincu' => "ٹرینکو میں رجسٹر کیوں؟  ",
    'lucrative-fare' => "منافع بخش کرایہ  ",
    'verified-shipper' => "تصدیق شدہ جہاز  ",
    'no-middleman' => "کوئی مڈل مین نہیں  ",
];
