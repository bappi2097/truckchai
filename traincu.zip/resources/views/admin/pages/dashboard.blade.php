@extends('admin.layout.app')
@section('title', "Dashboard | Admin")
@section('header')
    Dashboard <small>header small text goes here...</small>
@endsection
@section('content')
    bappi saha
@endsection
